#### GISC 422 T1 2021
# Point pattern analysis overview
This week simply download [this zip file](point-pattern-analysis.zip?raw=true) and unpack it a local folder, then follow the instructions in the files below. Unlike previous weeks, *the last of these is an assignment!*

- [How to do point pattern analysis](01-assignment-ppa-in-spatstat.md).
- [PPA with real data](02-ppa-with-real-data.md)
- [The assignment instructions](03-assignment-instructions.md)
