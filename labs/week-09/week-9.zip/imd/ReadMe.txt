About this spreadsheet																																						
Title:		The New Zealand Index of Multiple Deprivation (IMD)																							Description:	Downloadable spreadsheet of IMD ranks and deciles at the data zone level, with the usual resident population (URP) of data zones, 3 geographic boundary types, overall deprivation and 7 separate domains. 					There are also 7 versions of the index with one domain removed, to avoid circularity in analyses that focus on one of the domains.														Note: If two or more data zones had the same score, they received a rank equal to the mean of the corresponding rank of the tied scores (e.g. 6 data zones have an employment rank of 2595.5 because their employment 		domain scores were equal).																												Column headers:	DatazoneID			2013URPop						TA2013				TA2013Name			GED2014				GED2014Name	
		Unique ID for data zones	Total 2013 Usual Resident Population for data zones	Territorial Authority ID	Territorial Authority name	General Electoral District ID	General Electoral District name	

DHB12				DHB2012Name			IMDRank				EmpRank			IncRank		CriRank		HouRank		HlthRank	EduRank		AccRank	
District Health Board ID	District Health Board name	Overall deprivation rank	Employment rank		Income rank	Crime rank	Housing rank	Health rank	Education rank	Access to services rank	

IMDNoEmpR				IMDNoIncR				IMDNoCriR				IMDNoHouR				IMDNoHlthR					
IMD rank with Employment Domain removed	IMD rank with Income Domain removed	IMD rank with Crime Domain removed	IMD rank with Housing Domain removed	IMD rank with Health Domain removed	

IMDNoEduR				IMDNoAccR
IMD rank with Education Domain removed	IMD rank with Access Domain removed

IMDRankD			EmpRankD		IncRankD	CriRankD	HouRankD	HlthRankD	EduRankD		AccRankD			
Overall deprivation decile	Employment decile	Income decile	Crime decile	Housing decile	Health decile	Education decile	Access to services decile	

IMDNoEmpD					IMDNoIncD				IMDNoCriD				IMDNoHouD				IMDNoHlthD	
IMD decile with Employment Domain removed	IMD decile with Income Domain removed	IMD decile with Crime Domain removed	IMD decile with Housing Domain removed	IMD decile with Health Domain removed	

IMDNoEduD					IMDNoAccD
IMD decile with Education Domain removed	IMD decile with Access Domain removed


Data zones:	5,958	Total data zones. Data zones exclude inland and coastal water bodies. A combined population of 12,738 residents living in such areas was excluded.											712	Average Usual Resident Population 2013 of data zones																						
Contact details:Dr. Dan Exeter, Epidemiology and Biostatistics, School of Population Health, The University of Auckland 																																				
Email: 		d.exeter@auckland.ac.nz																																					
Phone:		64 9 923 4400																																					
Website:	http://www.fmhs.auckland.ac.nz/imd																									
Citation:	Exeter DJ, Zhao J, Crengle S, Lee A, Browne M (2017) The New Zealand Indices of Multiple Deprivation (IMD): A new suite of indicators for social and health research in Aotearoa, New Zealand. PLoS ONE 12(8): e0181260. https://doi.org/10.1371/journal.pone.0181260
							
Conditions of supply: If you publish, distribute or otherwise disseminate this work to the public the following attribution should be used:														Source: The University of Auckland. Index of Multiple Deprivation developed by Exeter et al 2017 and licensed by The University of Auckland for re-use under the Creative Commons Attribution 3.0 New Zealand licence.			

Copyright:	2017 � Daniel J Exeter, Jinfeng Zhao, Sue Crengle, Arier Chi-Lun Lee, Michael Browne																			
Funding:	Health Research Council of New Zealand (www.hrc.govt.nz)																													
Statistics New Zealand Disclaimer:																											The results presented in this spreadsheet are not official statistics, they have been created for research purposes using data provided by government departments and agencies, and data extracted from the Integrated Data Infrastructure (IDI), managed by Statistics New Zealand. 																								The results presented in this spreadsheet were developed by the author(s) not Statistics NZ or the University of Auckland. 															Access to the anonymised data used in this study was provided by Statistics NZ in accordance with security and confidentiality provisions of the Statistics Act 1975. 										Only people authorised by the Statistics Act 1975 are allowed to see data about a particular person, household, business, or organisation and the results in this paper have been confidentialised to protect these groups from identification. 																													Careful consideration has been given to the privacy, security, and confidentiality issues associated with using administrative and survey data in the IDI. Further detail can be found in the Privacy impact assessment for the Integrated Data Infrastructure available from www.stats.govt.nz. 																							The results are based in part on tax data supplied by Inland Revenue to Statistics NZ under the Tax Administration Act 1994.															This tax data must be used only for statistical purposes, and no individual information may be published or disclosed in any other form, or provided to Inland Revenue for administrative or regulatory purposes. 				Any person who has had access to the unit-record data has certified that they have been shown, have read, and have understood section 81 of the Tax Administration Act 1994, which relates to secrecy.
	Any discussion of data limitations or weaknesses is in the context of using the IDI for statistical purposes, and is not related to the data�s ability to support Inland Revenue�s core operational requirements.				
Attribution: This work is based on/includes data from the following sources:
	Data from Statistics New Zealand's Integrated Data Infrastructure (IDI) and Customised Data, which are licensed by Statistics New Zealand for re-use under the Creative Commons Attribution 3.0 New Zealand licence;�
	LINZ data, which are licensed by Land Information New Zealand (LINZ) for re-use under the Creative Commons Attribution 4.0 International�licence;
	The Sovereign in right of New Zealand acting by and through the Chief Executive of the Ministry of Social Development;
	The Sovereign in right of New Zealand acting by and through the Chief Executive of the Ministry of Health;
	The Sovereign in right of New Zealand acting by and through the Chief Executive of the Ministry of Education;
	The New Zealand Police;
	Inland Revenue Department of New Zealand;
	The Royal New Zealand College of General Practitioners.																																						
