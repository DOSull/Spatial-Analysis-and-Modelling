#### GISC 422 T1 2021
# Spatial autocorrelation overview
This week simply download [this zip file](spatial-autocorrelation.zip?raw=true) and unpack it a local folder, then follow the [instructions here](assignment-spatial-autocorrelation.md).
