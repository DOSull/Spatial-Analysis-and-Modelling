#### GISC 422 T2 2021
# Making maps in *R* overview
This week simply download [this zip file](making-maps-in-r.zip?raw=true) and unpack it a local folder, then follow the instructions on these pages:
+ [Making maps in *R*](01-making-maps-in-r.md).
+ [Simple data wrangling in *R*](02-data-wrangling-in-r.md).

## Some videos
These were made for another class I teach which makes use of `tmap` and `sf` and `dplyr`, and you might find them useful.

### Selecting and tidying data
[Filtering and selecting data](http://southosullivan.com/geog315/video/week-03-lab/geog315-week03-02-making-maps-filter-and-select.mp4) (6:07 min)

[Mutating data](http://southosullivan.com/geog315/video/week-03-lab/geog315-week03-03-making-maps-mutate.mp4) (3:09 min)

[Pipelines](http://southosullivan.com/geog315/video/week-03-lab/geog315-week03-04-making-maps-tidy-pipelines.mp4) (10:17 min)

### How to use the `tmap` functions
[Introduction to tmap](http://southosullivan.com/geog315/video/week-03-lab/geog315-week03-05-making-maps-tmap-intro.mp4) (2:58 min)

[Colour palettes 1](http://southosullivan.com/geog315/video/week-03-lab/geog315-week03-06-making-maps-tmap-palettes-1.mp4) (3:15 min)

[Colour palettes 2](http://southosullivan.com/geog315/video/week-03-lab/geog315-week03-07-making-maps-tmap-palettes-2.mp4) (6:36 min)

[The number of classes](http://southosullivan.com/geog315/video/week-03-lab/geog315-week03-08-making-maps-tmap-number-of-classes.mp4) (3:27 min)

[The classification style](http://southosullivan.com/geog315/video/week-03-lab/geog315-week03-09-making-maps-tmap-classification-styles.mp4) (7:24 min)

[Other map frills](http://southosullivan.com/geog315/video/week-03-lab/geog315-week03-10-making-maps-tmap-frills.mp4) (2:50 min)  
