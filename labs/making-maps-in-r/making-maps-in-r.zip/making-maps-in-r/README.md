#### GISC 422 T2 2021
# Making maps in *R* overview
This week simply download [this zip file](making-maps-in-r.zip?raw=true) and unpack it a local folder, then follow the [instructions here](making-maps-in-r.md).
