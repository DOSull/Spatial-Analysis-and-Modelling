#### GISC 422 T1 2020
# Week 1 Overview
This week we have a couple of things to do, which are explained in detail in the documents linked below.
+ [Familiarise with the _R_ and _RStudio_ environments](01-introducing-r-and-rstudio.md)
+ [Ensure that the environment is set up correctly](02-installing-packages.md)
+ [Do some simple data exploration](03-simple-data-exploration.md)
+ [Make some simple maps](04-simple-maps.md)
+ [Wrapping up](05-wrapping-up.md)
