#### GISC 422 T1 2021
# Statistical models
Some slides from another class to look at this week
+ [From overlay to regression](https://southosullivan.com/geog315/from-overlay-to-regression/)
+ [Introduction to regression](https://southosullivan.com/geog315/regression/)
+ [More on regression](https://southosullivan.com/geog315/more-on-regression/)

And then [a notebook to explore](statistical-models.md). If you [download the zip file](statistical-models.zip?raw=true) then you'll find the data and the RMarkdown version of the notebook in there too.
