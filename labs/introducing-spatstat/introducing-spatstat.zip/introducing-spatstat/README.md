#### GISC 422 T1 2021
# Introducing `spatstat` overview
This week simply download [this zip file](introducing-spatstat.zip?raw=true) and unpack it a local folder, then follow the [instructions here](introducing-spatstat.md).
