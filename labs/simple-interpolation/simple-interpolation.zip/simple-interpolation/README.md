#### GISC 422 T1 2021
# Simple interpolation overview
This week simply download [this zip file](simple-interpolation.zip?raw=true) and unpack it a local folder, then follow the [instructions here](simple-interpolation.md).
