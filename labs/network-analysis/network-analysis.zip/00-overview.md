#### GISC 422 T1 2020
# Network analysis overview
This week simply download [this zip file](network-analysis.zip?raw=true) and unpack it a local folder, then follow the [instructions here](network-analysis.md).
